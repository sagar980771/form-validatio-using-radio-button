function onSubmit() {
  let rolemodal = document.getElementsByName('radio');
   for (let i = 0; i < rolemodal.length; i++) {
    if (rolemodal[i].checked) {
      switch (rolemodal[i].value) {
        case 'role1':
          alert('you selected ' + rolemodal[i].value)
          break;
        case 'role2':
          alert('you selected ' + rolemodal[i].value)
          break;
        case 'role3':
          alert('you selected ' + rolemodal[i].value)
          break;
        case 'role4':
          alert('you selected ' + rolemodal[i].value)
          break;
        case 'role5':
          alert('you selected ' + rolemodal[i].value)
          break;
        default:
          alert('nothing selected')
          break;
       }
     }
//      else{
// alert('this is not a valid button');
//      }
     
  }
}